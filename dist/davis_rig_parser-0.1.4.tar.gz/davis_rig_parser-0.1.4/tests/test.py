#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 28 17:25:29 2023

@author: senecascott
"""

import davis_rig_parser as drp


df = drp.create_df(
    dir_name = '/home/senecascott/Documents/CodeVault/davis_rig_parser/tests/test_data', 
    info_name=None, 
    save_df=False
    )

